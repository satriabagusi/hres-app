

<div class="page-header d-print-none">
    <div class="container-xl">
        <div class="row g-2 align-items-center">
            <div class="col">
                <!-- Page pre-title -->
                <div class="page-pretitle"><?php echo e($title); ?></div>
                <h2 class="page-title"><?php echo e($subTitle); ?></h2>
                <div class="hr-text"></div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Satria\Documents\Sites\hres-app\resources\views/layouts/partials/header.blade.php ENDPATH**/ ?>