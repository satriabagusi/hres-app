<div>
    <div class="row mb-3 justify-content-center">
        <!--[if BLOCK]><![endif]--><?php if($projectContractId): ?>
            <div class="col-6">
                <div class="card card-body mb-3" wire:ignore>
                    <form wire:submit.prevent="uploadEmployee" class="space-y-4 mb-4">
                        <div>
                            <label for="employee_xls">Upload data Pekerja menggunakan Excel</label>
                            <input type="file" wire:model="employee_xls" id="filepond-upload" class="filepond"
                                accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                                multiple="false" />
                            
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['employee_xls'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <button type="submit" class="btn btn-primary" wire:loading.attr="disabled">
                            <span wire:loading>
                                <span class="spinner-border spinner-border-sm me-2" role="status"></span> Memproses
                                File
                                ...
                            </span>
                            <span wire:loading.remove>
                                <i class="ti ti-upload"></i> Upload Data
                            </span>
                        </button>
                    </form>

                    <?php
                        $companyName = Auth::user()->company_name;
                    ?>
                    <p class="text-secondary text-muted text-center mb-2">Untuk format file, silakan download template
                        di
                        bawah
                        ini.</p>
                    <a class="btn btn-info" href="<?php echo e(route('contractor.download-template-pekerja')); ?>">
                        <i class="ti ti-download"></i> &nbsp; Download Template Pekerja
                    </a>
                </div>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <hr>
        <div class="col-12">
            <div class="card">
                <div class="card-table">
                    <div class="card-header">
                        <div class="row w-full">
                            <div class="col">
                                <h3 class="card-title mb-0">Draft Pekerja</h3>
                                <p class="text-secondary m-0 small">Data Draft Pekerja Kontraktor. (Data yang sudah di
                                    upload
                                    oleh anda akan muncul disini)</p>
                            </div>
                            <div class="col-md-auto col-sm-12">
                                <button class="btn btn-outline-green" id="btn-submit-all-employee">
                                    <i class="ti ti-circle-check"></i> &nbsp; Ajukan Semua Pekerja
                                </button>
                            </div>
                            <div class="col-md-auto col-sm-12">
                                <div class="dropdown">
                                    <a class="btn btn-outline-azure dropdown-toggle" data-bs-toggle="dropdown">
                                        <span id="page-count" class="me-1">Tampilkan <?php echo e($totalPaginate); ?></span>
                                        <span>data</span>
                                    </a>
                                    <div class="dropdown-menu">
                                        <button type="button" class="dropdown-item"
                                            wire:click="$set('totalPaginate', 10)">10
                                            data</button>
                                        <button type="button" class="dropdown-item"
                                            wire:click="$set('totalPaginate', 20)">20
                                            data</button>
                                        <button type="button" class="dropdown-item"
                                            wire:click="$set('totalPaginate', 50)">50
                                            data</button>
                                        <button type="button" class="dropdown-item"
                                            wire:click="$set('totalPaginate', 100)">100
                                            data</button>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-auto col-sm-12">
                                <div class="ms-auto d-flex flex-wrap btn-list">
                                    <div class="input-group input-group-flat w-auto">
                                        <span class="input-group-text">
                                            <!-- Download SVG icon from http://tabler.io/icons/icon/search -->
                                            <i class="ti ti-search"></i>
                                        </span>
                                        <input id="advanced-table-search" type="text" class="form-control"
                                            autocomplete="off" placeholder="Cari ... " wire:model.live='search' />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="advanced-table">
                        <div class="table-responsive">
                            <table class="table table-vcenter table-selectable">
                                <thead>
                                    <tr>
                                        <th>NO</th>
                                        <th>Nama Pekerja</th>
                                        <th>USIA</th>
                                        <th>NIK</th>
                                        <th>Jabatan</th>
                                        <th>Status</th>
                                        <th>Tempat Lahir</th>
                                        <th>Tanggal Lahir</th>
                                        <th>#</th>
                                    </tr>
                                </thead>
                                <tbody class="table-tbody">
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr
                                            class=<?php echo e(\Carbon\Carbon::parse($item->birth_date)->age > 56 ? 'bg-red-lt' : ''); ?>>
                                            
                                            <td width="50px" class="text-center">
                                                
                                                <?php echo e($loop->iteration + ($employees->currentPage() - 1) * $employees->perPage()); ?>

                                            </td>
                                            <td>
                                                <span class="text-body"><?php echo e($item->full_name); ?></span>
                                                <span class="small fw-bold text-muted">
                                                    <br>
                                                    <i
                                                        class='<?php echo e($item->photo ? 'ti ti-check text-green' : 'ti ti-x text-red'); ?>'>
                                                    </i>
                                                    Foto &nbsp; |
                                                    <i
                                                        class='<?php echo e($item->ktp_document ? 'ti ti-check text-green' : 'ti ti-x text-red'); ?>'></i>
                                                    </i>
                                                    KTP &nbsp;
                                                    |
                                                    <i
                                                        class='<?php echo e($item->form_b_document ? 'ti ti-check text-green' : 'ti ti-x text-red'); ?>'></i>
                                                    </i>
                                                    Form B
                                                    <!--[if BLOCK]><![endif]--><?php if(\Carbon\Carbon::parse($item->birth_date)->age > 56): ?>
                                                        | <i
                                                            class='<?php echo e($item->age_justification_document ? 'ti ti-check text-green' : 'ti ti-x text-red'); ?>'></i>
                                                        Justifikasi Umur
                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                </span>

                                            </td>
                                            <td class=""><?php echo e(\Carbon\Carbon::parse($item->birth_date)->age); ?></td>
                                            <td class=""><?php echo e($item->nik); ?></td>
                                            <td class=""><?php echo e($item->position); ?></td>
                                            <td class="sort-status">
                                                <!--[if BLOCK]><![endif]--><?php if($item->status == 'approved'): ?>
                                                    <span class="badge bg-lime text-lime-fg">Disetujui</span>
                                                <?php elseif($item->status == 'draft'): ?>
                                                    <span class="badge bg-orange text-orange-fg">Draft</span>
                                                <?php elseif($item->status == 'submitted'): ?>
                                                    <span class="badge bg-blue text-blue-fg">Dikirim</span>
                                                <?php elseif($item->status == 'rejected'): ?>
                                                    <span class="badge bg-red text-red-fg">Ditolak</span>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            </td>
                                            <td class=""><?php echo e($item->birth_place); ?></td>
                                            <td class="">
                                                <?php echo e(\Carbon\Carbon::parse($item->birth_date)->format('d-m-Y')); ?>

                                            </td>
                                            <td>
                                                <!--[if BLOCK]><![endif]--><?php if(
                                                    $item->photo &&
                                                        $item->ktp_document &&
                                                        $item->form_b_document &&
                                                        ($item->age_justification_document || \Carbon\Carbon::parse($item->birth_date)->age <= 56)): ?>
                                                    <button class="btn btn-ghost-green btn-submit-employee"
                                                        type="button" data-employee-id="<?php echo e($item->id); ?>">
                                                        <i class="ti ti-circle-check"></i>
                                                        Ajukan
                                                    </button>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                <button class="btn btn-ghost-cyan" type="button"
                                                    wire:click="viewDocument('<?php echo e($item->id); ?>')">
                                                    <i class="ti ti-file-type-pdf "></i>
                                                    Dokumen
                                                </button>
                                                <button class="btn btn-ghost-danger" type="button"
                                                    wire:click="deleteDraft('<?php echo e($item->id); ?>')">
                                                    <i class="ti ti-trash"></i>
                                                    Hapus
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </tbody>
                            </table>
                        </div>
                        <div class="card-footer d-flex align-items-center">

                            <div class="pagination m-0 ms-auto">
                                <?php echo e($employees->links(data: ['scrollTo' => false])); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <div class="modal fade" id="modalDocument" tabindex="-1" wire:ignore.self>
        <div class="modal-dialog modal-xl modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Modal Upload Data</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" wire:ignore>
                    <form wire:submit.prevent="uploadDocument" class="space-y-4 mb-4">
                        <div class="row">

                            <div class="col-4">
                                <label for="ktp_document">Upload File KTP</label>
                                <input type="file" id="filepond-upload-ktp" class="filepond"
                                    accept="application/pdf" multiple="false" />
                                
                                
                            </div>

                            <div class="col-4">
                                <label for="photo_document">Upload File Pas Foto</label>
                                <input type="file" id="filepond-upload-pas-foto" class="filepond"
                                    accept="image/png, image/jpeg, image/jpg" multiple="false" />
                                
                                
                            </div>

                            <div class="col-4">
                                <label for="form_b_document">Upload File Form B</label>
                                <input type="file" id="filepond-upload-form-b" class="filepond"
                                    accept="application/pdf" multiple="false" />
                                
                                
                            </div>

                            <div class="col-4" id="justifikasi-usia-element">
                                <label for="age_justification_document">Upload File Justifikasi Usia</label>
                                <input type="file" id="filepond-upload-justifikasi-usia" class="filepond"
                                    accept="application/pdf" multiple="false" />
                                
                                
                            </div>

                        </div>

                        <button type="submit" class="btn btn-primary" wire:loading.attr="disabled">
                            <span wire:loading>
                                <span class="spinner-border spinner-border-sm me-2" role="status"></span>
                                Memproses File
                                ...
                            </span>
                            <span wire:loading.remove>
                                <i class="ti ti-upload"></i> Upload Data
                            </span>
                        </button>
                    </form>
                </div>
                <div class="modal-body">
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['ktp_document'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['photo_document'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form_b_document'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['age_justification_document'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
                <!--[if BLOCK]><![endif]--><?php if($photoUrl || $ktpUrl || $formBUrl || $ageJustificationUrl): ?>
                    <div class="modal-body">
                        <p class="text-danger small"> <b>*PERHATIAN*</b> Jika upload dokumen yang sudah ada, maka
                            akan
                            menggantikan dokumen sebelumnya</p>
                        <h3>Dokumen yang sudah di upload :</h3>
                        <!--[if BLOCK]><![endif]--><?php if($ktpUrl): ?>
                            <div class="mt-2">
                                <a href="<?php echo e($ktpUrl); ?>" target="_blank" class="btn btn-outline-primary btn-sm"
                                    onclick="window.open(this.href, 'new', 'popup'); return false;">
                                    <i class="ti ti-file"></i> Lihat Dokumen KTP
                                </a>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <!--[if BLOCK]><![endif]--><?php if($photoUrl): ?>
                            <div class="mt-2">
                                <a href="<?php echo e($photoUrl); ?>" target="_blank" class="btn btn-outline-primary btn-sm"
                                    onclick="window.open(this.href, 'new', 'popup'); return false;">
                                    <i class="ti ti-file"></i> Lihat Dokumen Pas Foto
                                </a>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <!--[if BLOCK]><![endif]--><?php if($formBUrl): ?>
                            <div class="mt-2">
                                <a href="<?php echo e($formBUrl); ?>" target="_blank" class="btn btn-outline-primary btn-sm"
                                    onclick="window.open(this.href, 'new', 'popup'); return false;">
                                    <i class="ti ti-file"></i> Lihat Dokumen Form B
                                </a>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <!--[if BLOCK]><![endif]--><?php if($ageJustificationUrl): ?>
                            <div class="mt-2">
                                <a href="<?php echo e($ageJustificationUrl); ?>" target="_blank"
                                    class="btn btn-outline-primary btn-sm"
                                    onclick="window.open(this.href, 'new', 'popup'); return false;">
                                    <i class="ti ti-file"></i> Lihat Dokumen Keterangan Umur
                                </a>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <div class="modal-footer">
                    <button type="button" class="btn me-auto" data-bs-dismiss="modal">Tutup</button>
                </div>
            </div>
        </div>
    </div>
    <div id="cropperModal" class="modal-cropper">
        <div class="modal-content-cropper">
            <div class="cropper-container">
                <img id="cropperImage" style="max-width:100%; max-height:100%;">
            </div>
            <div class="cropper-actions">
                <button id="cropConfirm" class="btn btn-primary">Potong & Simpan</button>
                <button id="cropCancel" class="btn btn-secondary">Cancel</button>
            </div>
        </div>
    </div>
</div>


<?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('livewire:init', () => {
            console.log('Livewire loaded, initializing FilePond...');

            var bootstrap = tabler.bootstrap;

            const modalDocument = new bootstrap.Modal('#modalDocument', {});

            // Registrasi semua plugin yang dibutuhkan
            FilePond.registerPlugin(
                FilePondPluginFileValidateType,
                FilePondPluginFileValidateSize,
                FilePondPluginPdfPreview,
                FilePondPluginImagePreview,
                FilePondPluginImageEdit,
            );

            const inputElement = document.getElementById('filepond-upload');

            const pond = FilePond.create(inputElement, {
                allowMultiple: false,
                maxFiles: 1,
                // excel file allowed
                acceptedFileTypes: ['application/vndopenxmlformats-officedocument.spreadsheetml.sheet',
                    'application/vnd.ms-excel'
                ],
                fileValidateTypeLabelExpectedTypes: 'Hanya file Excel (.xlsx, .xls) yang diperbolehkan',
                maxFileSize: '2MB',
                labelIdle: `<div class="text-center mb-2"> <i class="ti ti-upload fs-2 mb-3 text-muted"></i><br><strong>Drag & drop</strong> atau <span class="filepond--label-action">klik di sini</span> untuk upload</div>`,
                credits: false,
                // storeAsFile: true,
                labelFileTypeNotAllowed: 'Hanya file Excel (.xlsx, .xls) yang diperbolehkan',
                labelMaxFileSizeExceeded: 'Ukuran file terlalu besar (maksimal 2MB)',
                labelMaxFileSize: 'Maksimal ukuran file adalah 2MB',
                labelFileProcessingError: 'Terjadi kesalahan saat mengunggah file',
                labelFileProcessing: 'Mengunggah file...',
                labelFileProcessingComplete: 'File berhasil diunggah',
                labelFileProcessingAborted: 'Pengunggahan file dibatalkan',
            });

            let uploadedFileTmp = null;

            pond.on('addfile', (error, file) => {
                if (!error) {
                    inputElement.dispatchEvent(new Event('change', {
                        bubbles: true
                    }));
                    const fileData = file.file;
                    window.Livewire.find('<?php echo e($_instance->getId()); ?>').upload('employee_xls', fileData, (fileName) => {
                        console.log('File uploaded successfully:', fileName);
                        uploadedFileTmp = fileName;
                    }, (error) => {
                        console.error('Error uploading file:', error);
                        // Show error message to user
                        Swal.fire({
                            icon: 'error',
                            title: 'Upload Gagal',
                            text: 'Terjadi kesalahan saat mengunggah file. Silakan coba lagi.',
                            confirmButtonText: 'OK'
                        });
                    });
                }
            });

            pond.on('removefile', (err, file) => {
                console.log('File removed');
                inputElement.value = '';
                inputElement.dispatchEvent(new Event('change', {
                    bubbles: true
                }));

                if (uploadedFileTmp) {
                    window.Livewire.find('<?php echo e($_instance->getId()); ?>').removeUpload('employee_xls', uploadedFileTmp);
                    uploadedFileTmp = null;
                }
            });


            Livewire.on('uploadSuccess', (fileName) => {
                console.log('Data Pekerja berhasil di upload:', fileName);
                // Reset the pond after successful upload
                pond.removeFile(pond.getFile(fileName));
            });

            let uploadedKtpTmp = null;
            let uploadedPhotoTmp = null;
            let uploadedFormBTemp = null;
            let uploadedAgeJustificationTmp = null;

            const inputKtpElement = document.getElementById('filepond-upload-ktp');
            const inputPhotoElement = document.getElementById('filepond-upload-pas-foto');
            const inputFormBElement = document.getElementById('filepond-upload-form-b');
            const inputAgeJustificationElement = document.getElementById('filepond-upload-justifikasi-usia');


            Livewire.on('viewDocumentModal', (e) => {
                console.log(e);
                // console.log('KTP URL: ', e.ktpUrl);
                // console.log('PHOTO URL: ', e.photoUrl);
                // console.log('Form B URL: ', e.formBurl);

                modalDocument.show();

                document.getElementById('modalDocument').addEventListener('shown.bs.modal', () => {
                    document.querySelector('.modal-title').textContent =
                        `Lengkapi Dokumen Pekerja: ${e.full_name}`;

                    if (!FilePond.find(inputKtpElement)) {
                        console.log('Creating FilePond instance for KTP upload');
                        const pondKtp = FilePond.create(inputKtpElement, {
                            allowMultiple: false,
                            maxFiles: 1,
                            acceptedFileTypes: ['application/pdf'],
                            fileValidateTypeLabelExpectedTypes: 'Hanya file PDF yang diperbolehkan',
                            maxFileSize: '2MB',
                            labelIdle: `<div class="text-center mb-2"> <i class="ti ti-upload fs-2 mb-3 text-muted"></i><br><strong>Drag & drop</strong> atau <span class="filepond--label-action">klik di sini</span> untuk upload KTP</div>`,
                            credits: false,
                            allowReplace: true,
                            allowRemove: true,
                            allowRevert: false,
                        });

                        pondKtp.on('addfile', (error, file) => {
                            if (!error) {
                                // Jangan upload file jika file berasal dari preload (type: 'local')
                                if (file.origin === FilePond.FileOrigin.LOCAL) {
                                    console.log(
                                        'File berasal dari preload, tidak perlu upload ulang.'
                                    );
                                    return;
                                }

                                inputKtpElement.dispatchEvent(new Event('change', {
                                    bubbles: true
                                }));

                                const fileData = file.file;

                                window.Livewire.find('<?php echo e($_instance->getId()); ?>').upload('ktp_document', fileData, (fileName) => {
                                    console.log('KTP uploaded successfully:',
                                        fileName);
                                    uploadedKtpTmp = fileName;
                                }, (error) => {
                                    console.error('Error uploading KTP:', error);
                                    Swal.fire({
                                        icon: 'error',
                                        title: 'Upload Gagal',
                                        text: 'Terjadi kesalahan saat mengunggah KTP. Silakan coba lagi.',
                                        confirmButtonText: 'OK'
                                    });
                                });
                            }
                        });

                        pondKtp.on('removefile', (err, file) => {
                            console.log('File removed');
                            inputKtpElement.value = '';
                            inputKtpElement.dispatchEvent(new Event('change', {
                                bubbles: true
                            }));

                            if (uploadedKtpTmp) {
                                window.Livewire.find('<?php echo e($_instance->getId()); ?>').removeUpload('ktp_document', uploadedKtpTmp);
                                uploadedKtpTmp = null;
                            }
                        });
                    }

                    if (!FilePond.find(inputPhotoElement)) {
                        let cropper = null;
                        let isCropping = false;
                        if(cropper) cropper.destroy();
                        const pondPhoto = FilePond.create(inputPhotoElement, {
                            allowMultiple: false,
                            maxFiles: 1,
                            acceptedFileTypes: ['image/png', 'image/jpeg', 'image/jpg'],
                            fileValidateTypeLabelExpectedTypes: 'Hanya file Gambar (PNG, JPEG) yang diperbolehkan',
                            maxFileSize: '2MB',
                            labelIdle: `<div class="text-center mb-2"> <i class="ti ti-upload fs-2 mb-3 text-muted"></i><br><strong>Drag & drop</strong> atau <span class="filepond--label-action">klik di sini</span> untuk upload Pas Foto</div>`,
                            credits: false,
                            allowReplace: true,
                            allowRemove: true,
                            allowRevert: false,
                            allowImageEdit: true,
                            imageEditIconEdit: '<p class="fw-bolder"><i class="ti ti-pencil"></i>Crop</p>',
                            imageEditEditor: {
                                open: (file) => {
                                    return new Promise((resolve, reject) => {
                                        const reader = new FileReader();
                                        reader.onload = function(evt) {
                                            const img = document
                                                .getElementById(
                                                    'cropperImage');
                                            img.src = evt.target.result;

                                            const modal = document
                                                .getElementById(
                                                    'cropperModal');
                                            modal.style.display = 'flex';

                                            if (cropper) cropper.destroy();

                                            cropper = new Cropper(img, {
                                                aspectRatio: 1,
                                                viewMode: 1
                                            });
                                        };

                                        if (file instanceof Blob ||
                                            file instanceof File) {
                                            reader.readAsDataURL(file);
                                        } else {
                                            console.error(
                                                'File sent to editor is not a Blob/File:',
                                                file);
                                            reject();
                                        }
                                    });
                                },
                            }
                        });

                        pondPhoto.on('addfile', (error, file) => {
                            if (error) return;
                            // Tidak ada lagi trigger modal cropper di sini!
                            // Hanya proses upload
                            window.Livewire.find('<?php echo e($_instance->getId()); ?>').upload('photo_document', file.file, (fileName) => {
                                console.log('Photo Uploaded successfully:', fileName);
                                uploadedPhotoTmp = fileName;
                            }, (error) => {
                                console.error('Error Uploading Photo:', error);
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Gagal Upload',
                                    text: 'Terjadi error saat upload pas foto. coba lagi.',
                                    confirmButtonText: 'OK'
                                });
                            });
                        });
                        
                        // Tombol konfirmasi crop
                        document.getElementById('cropConfirm').onclick = function () {
                          if (!cropper) return;

                            cropper.getCroppedCanvas({ width: 300, height: 300 }).toBlob(blob => {
                                cropper.destroy();
                                cropper = null;
                                document.getElementById('cropperModal').style.display = 'none';
                        
                                const croppedFile = new File([blob], `cropped_${Date.now()}.png`, { type: 'image/png' });
                        
                                pondPhoto.removeFiles();
                                pondPhoto.addFile(croppedFile);
                        
                                // Hapus file tmp lama
                                if (uploadedPhotoTmp) {
                                    window.Livewire.find('<?php echo e($_instance->getId()); ?>').removeUpload('photo_document', uploadedPhotoTmp);
                                    uploadedPhotoTmp = null;
                                }
                        
                                window.Livewire.find('<?php echo e($_instance->getId()); ?>').upload('photo_document', croppedFile, (fileName) => {
                                    console.log('Pas Foto uploaded successfully:', fileName);
                                    uploadedPhotoTmp = fileName;
                                }, (error) => {
                                    console.error('Error uploading Pas Foto:', error);
                                    Swal.fire({
                                        icon: 'error',
                                        title: 'Upload Gagal',
                                        text: 'Terjadi kesalahan saat mengunggah Pas Foto. Silakan coba lagi.',
                                        confirmButtonText: 'OK'
                                    });
                                });
                        
                            }, 'image/png');
                        };
                        
                        // Tombol batal crop
                        document.getElementById('cropCancel').onclick = function () {
                            if (cropper) cropper.destroy();
                            cropper = null;
                            document.getElementById('cropperModal').style.display = 'none';
                        
                            // Optionally: remove file if cancel crop means cancel upload
                            cropper = null;
                            isCropping = false;
                        };
                        
                        pondPhoto.on('removefile', () => {
                            inputPhotoElement.value = '';
                            inputPhotoElement.dispatchEvent(new Event('change', { bubbles: true }));
                        
                            if (uploadedPhotoTmp) {
                                window.Livewire.find('<?php echo e($_instance->getId()); ?>').removeUpload('photo_document', uploadedPhotoTmp);
                                uploadedPhotoTmp = null;
                            }
                        });



                    }

                    if (!FilePond.find(inputFormBElement)) {
                        const pondFormB = FilePond.create(inputFormBElement, {
                            allowMultiple: false,
                            maxFiles: 1,
                            acceptedFileTypes: ['application/pdf'],
                            fileValidateTypeLabelExpectedTypes: 'Hanya file PDF yang diperbolehkan',
                            maxFileSize: '2MB',
                            labelIdle: `<div class="text-center mb-2"> <i class="ti ti-upload fs-2 mb-3 text-muted"></i><br><strong>Drag & drop</strong> atau <span class="filepond--label-action">klik di sini</span> untuk upload Form B</div>`,
                            credits: false,
                            // storeAsFile: true,
                        });

                        pondFormB.on('addfile', (error, file) => {
                            if (!error) {
                                inputFormBElement.dispatchEvent(new Event(
                                    'change', {
                                        bubbles: true
                                    }));
                                const fileData = file.file;
                                window.Livewire.find('<?php echo e($_instance->getId()); ?>').upload('form_b_document', fileData, (
                                    fileName) => {
                                    console.log(
                                        'Form B uploaded successfully:',
                                        fileName);
                                    uploadedFormBTemp = fileName;
                                }, (error) => {
                                    console.error('Error uploading Form B:',
                                        error);
                                    Swal.fire({
                                        icon: 'error',
                                        title: 'Upload Gagal',
                                        text: 'Terjadi kesalahan saat mengunggah Form B. Silakan coba lagi.',
                                        confirmButtonText: 'OK'
                                    });
                                });
                            }
                        });
                        pondFormB.on('removefile', (err, file) => {
                            console.log('File removed');
                            inputFormBElement.value = '';
                            inputFormBElement.dispatchEvent(new Event(
                                'change', {
                                    bubbles: true
                                }));

                            if (uploadedFormBTemp) {
                                window.Livewire.find('<?php echo e($_instance->getId()); ?>').removeUpload('form_b_document',
                                    uploadedFormBTemp);
                                uploadedFormBTemp = null;
                            }
                        });
                    }

                    if (e.employeeAge > 55) {
                        document.getElementById('justifikasi-usia-element').style.display = 'block';
                        if (!FilePond.find(inputAgeJustificationElement)) {
                            const pondAgeJustification = FilePond.create(
                                inputAgeJustificationElement, {
                                    allowMultiple: false,
                                    maxFiles: 1,
                                    acceptedFileTypes: ['application/pdf'],
                                    fileValidateTypeLabelExpectedTypes: 'Hanya file PDF yang diperbolehkan',
                                    maxFileSize: '2MB',
                                    labelIdle: `<div class="text-center mb-2"> <i class="ti ti-upload fs-2 mb-3 text-muted"></i><br><strong>Drag & drop</strong> atau <span class="filepond--label-action">klik di sini</span> untuk upload Dokumen Justifikasi Usia</div>`,
                                    credits: false,
                                    // storeAsFile: true,
                                });

                            pondAgeJustification.on('addfile', (error,
                                file) => {
                                if (!error) {
                                    inputAgeJustificationElement.dispatchEvent(
                                        new Event('change', {
                                            bubbles: true
                                        }));
                                    const fileData = file.file;
                                    window.Livewire.find('<?php echo e($_instance->getId()); ?>').upload('age_justification_document',
                                        fileData, (fileName) => {
                                            console.log(
                                                'Dokumen Justifikasi Usia uploaded successfully:',
                                                fileName);
                                            uploadedAgeJustificationTmp = fileName;
                                        }, (error) => {
                                            console.error(
                                                'Error uploading Dokumen Justifikasi Usia:',
                                                error);
                                            Swal.fire({
                                                icon: 'error',
                                                title: 'Upload Gagal',
                                                text: 'Terjadi kesalahan saat mengunggah Dokumen Justifikasi Usia. Silakan coba lagi.',
                                                confirmButtonText: 'OK'
                                            });
                                        });
                                }
                            });
                            pondAgeJustification.on('removefile', (err,
                                file) => {
                                console.log('File removed');
                                inputAgeJustificationElement.value = '';
                                inputAgeJustificationElement.dispatchEvent(
                                    new Event('change', {
                                        bubbles: true
                                    }));

                                if (uploadedAgeJustificationTmp) {
                                    window.Livewire.find('<?php echo e($_instance->getId()); ?>').removeUpload(
                                        'age_justification_document',
                                        uploadedAgeJustificationTmp);
                                    uploadedAgeJustificationTmp = null;
                                }
                            });

                        }
                    } else {
                        uploadedAgeJustificationTmp = null;
                        document.getElementById('justifikasi-usia-element').style.display = 'none';
                    }
                });
            });

            document.getElementById('modalDocument').addEventListener('hidden.bs.modal', () => {
                console.log('Modal closed, resetting FilePond instances');
                // Reset all FilePond instances
                FilePond.find(document.getElementById('filepond-upload-ktp'))?.removeFile();
                FilePond.find(document.getElementById('filepond-upload-pas-foto'))?.removeFile();
                FilePond.find(document.getElementById('filepond-upload-form-b'))?.removeFile();
                FilePond.find(document.getElementById('filepond-upload-justifikasi-usia'))?.removeFile();

                FilePond.find(document.getElementById('filepond-upload-ktp'))?.destroy();
                FilePond.find(document.getElementById('filepond-upload-pas-foto'))?.destroy();
                FilePond.find(document.getElementById('filepond-upload-form-b'))?.destroy();
                FilePond.find(document.getElementById('filepond-upload-justifikasi-usia'))?.destroy();

                uploadedKtpTmp = null;
                uploadedPhotoTmp = null;
                uploadedFormBTemp = null;
                uploadedAgeJustificationTmp = null;
            });

            document.getElementById('btn-submit-all-employee').addEventListener('click', () => {
                Swal.fire({
                    title: 'Ajukan semua data Pekerja? ',
                    html: '<span class=" text-muted">Pekerja yang di ajukan hanya pekerja yang sudah di upload dokumen nya, jika belum maka tidak akan di ajukan secara otomatis</span>',
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonText: 'Ya, ajukan!',
                    cancelButtonText: 'Batal',
                    confirmButtonColor: '#388cda',
                    cancelButtonColor: '#dc3545',
                }).then((result) => {
                    if (result.isConfirmed) {
                        Livewire.dispatch('submitAllEmployee')
                    }
                });
            });

            Livewire.on('uploadSucceed', () => {
                console.log('Data Pekerja berhasil di upload');
                // Reset the pond after successful upload
                modalDocument.hide();
            })

            document.querySelectorAll('.btn-submit-employee').forEach((button) => {
                button.addEventListener('click', () => {
                    Swal.fire({
                        title: 'Ajukan data Pekerja? ',
                        html: '<span class=" text-muted">Ajukan Pekerja ini ?</span>',
                        icon: 'question',
                        showCancelButton: true,
                        confirmButtonText: 'Ya, ajukan!',
                        cancelButtonText: 'Batal',
                        confirmButtonColor: '#388cda',
                        cancelButtonColor: '#dc3545',
                    }).then((result) => {
                        if (result.isConfirmed) {
                            var employeeId = button.getAttribute('data-employee-id');
                            Livewire.dispatch('submitEmployee', {
                                id: employeeId
                            });
                        }
                    })
                });
            });

        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH /www/wwwroot/hres.ciptoonline.com/hres-app/resources/views/livewire/dashboard/contractor/list-draft-employee.blade.php ENDPATH**/ ?>