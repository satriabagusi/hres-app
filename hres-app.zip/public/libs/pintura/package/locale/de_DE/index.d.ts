export const LocaleAnnotate: { [key: string]: any };
export const LocaleCore: { [key: string]: any };
export const LocaleCrop: { [key: string]: any };
export const LocaleDecorate: { [key: string]: any };
export const LocaleFilter: { [key: string]: any };
export const LocaleFinetune: { [key: string]: any };
export const LocaleFrame: { [key: string]: any };
export const LocaleResize: { [key: string]: any };
export const LocaleRedact: { [key: string]: any };
export const LocaleSticker: { [key: string]: any };
export const LocaleTrim: { [key: string]: any };
export const LocaleFill: { [key: string]: any };
export const LocaleMarkupEditor: { [key: string]: any };

export {};
