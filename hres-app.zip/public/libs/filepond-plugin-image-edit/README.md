# Image Edit plugin for FilePond

[![npm version](https://badge.fury.io/js/filepond-plugin-image-edit.svg)](https://badge.fury.io/js/filepond)

https://pqina.nl/filepond/docs/patterns/plugins/image-edit/

The Image Edit plugin facilitates integration of image editor libraries like [Doka.js](https://pqina.nl/doka/) with FilePond. 

**This is not an image editor in itself, it requires another library to edit the images**
