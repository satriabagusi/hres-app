import './controls/input';
import IMask from './core/holder';
export default IMask;
//# sourceMappingURL=imask.d.ts.map