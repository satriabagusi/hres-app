{{-- <header class="navbar-expand-md">
    <div class="collapse navbar-collapse" id="navbar-menu">
        <div class="navbar">
            <div class="container-xl">
                <div class="row flex-fill align-items-center">
                    <div class="col">
                        <ul class="navbar-nav">
                            </ul>
                    </div>
                    <div class="col-2 d-none d-xxl-block">
                        <div class="my-2 my-md-0 flex-grow-1 flex-md-grow-0 order-first order-md-last">
                           </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header> --}}

<div class="page-header d-print-none">
    <div class="container-xl">
        <div class="row g-2 align-items-center">
            <div class="col">
                <!-- Page pre-title -->
                <div class="page-pretitle">{{ $title }}</div>
                <h2 class="page-title">{{ $subTitle }}</h2>
                <div class="hr-text"></div>
            </div>
        </div>
    </div>
</div>
